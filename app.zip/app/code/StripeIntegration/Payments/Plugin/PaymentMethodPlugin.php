<?php

namespace StripeIntegration\Payments\Plugin;

use StripeIntegration\Payments\Helper\Logger;

class PaymentMethodPlugin
{
    // public function __construct(
    //     \Magento\Framework\ObjectManager\ObjectManager $objectManager
    // )
    // {

    // }

    // public function afterIsAvailable($interceptor, $result)
    // {
    //     return $result;
    // }
}
