<?php
/**
 *   Copyright © 2019 Magenest. All rights reserved.
 *   See COPYING.txt for license details.
 *
 *   Magenest_ImageGallery extension
 *   NOTICE OF LICENSE
 *
 */

/**
 * Created by PhpStorm.
 */
namespace Magenest\ImageGallery\Block\Adminhtml\Gallery\Edit;

/**
 * Class Js
 * @package Magenest\ImageGallery\Block\Adminhtml\Gallery\Edit
 */
class Js extends \Magento\Backend\Block\Template
{
}
