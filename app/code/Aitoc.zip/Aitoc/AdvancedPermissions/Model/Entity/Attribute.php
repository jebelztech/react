<?php
/**
 * @author Aitoc Team
 * @copyright Copyright (c) 2022 Aitoc (https://www.aitoc.com)
 * @package Aitoc_AdvancedPermissions
 */


namespace Aitoc\AdvancedPermissions\Model\Entity;

class Attribute extends \Magento\Eav\Model\Entity\Attribute implements \Magento\Framework\View\Element\Block\ArgumentInterface
{

}
