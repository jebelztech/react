<?php

namespace Amasty\Mostviewed\Controller\Adminhtml\Product\Mui;

class Render extends \Magento\Ui\Controller\Adminhtml\Index\Render
{
    const ADMIN_RESOURCE = 'Amasty_Mostviewed::rule';
}
