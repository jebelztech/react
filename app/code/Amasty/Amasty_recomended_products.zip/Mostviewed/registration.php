<?php
/**
 * Copyright © 2015 Amasty. All rights reserved.
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Amasty_Mostviewed',
    __DIR__
);
