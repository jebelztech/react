var config = {
    paths: {
         popper:                 'js/popper.min',
         bootstrap:    			'js/bootstrap.min',
         owlcarousel3:          'js/owl.carousel', 
       
    }
   
};




