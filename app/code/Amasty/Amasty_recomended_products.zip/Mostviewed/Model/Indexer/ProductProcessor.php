<?php

namespace Amasty\Mostviewed\Model\Indexer;

use Magento\Framework\Indexer\AbstractProcessor;

class ProductProcessor extends AbstractProcessor
{
    const INDEXER_ID = 'amasty_mostviewed_product_rule';
}
