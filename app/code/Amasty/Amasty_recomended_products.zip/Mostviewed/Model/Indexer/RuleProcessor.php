<?php

namespace Amasty\Mostviewed\Model\Indexer;

use Magento\Framework\Indexer\AbstractProcessor;

class RuleProcessor extends AbstractProcessor
{
    const INDEXER_ID = 'amasty_mostviewed_rule_product';
}
