# Change Log
All notable changes to this extension will be documented in this file.
This extension adheres to [Magenest](http://store.magenest.com/).

##[1.1.3] - 2019-11-15
Update database

##[1.1.0] - 2019-11-12
1. Compatible with Magento 2.2.x, 2.3.x
2. Add more field for gallery and images.
3. Show all images in gallery page with lazy load.
4. Allow admins to create gallery with two layouts:4 columns and grid.
5. Assign gallery to category and product page(show slider),choose width, height,number images for slider.
6. Customer can react with the image(love icon).
7. SEO configuration.
8. Share gallery,image on frontend page(fb,twitter,pinterest).
9. Link image with product(View product button).
10. Show image in lightbox.
11. Hover effect for gallery page(zoom-in,zoom-out) in config.

## [1.0.0] - 2017-04-25
### Releases
1. Allow admins to add new images
2. Allow admins to add new gallerys
4. Allow admins to config size image , assign images and gallerys to page
5. Show images and galerrys on frontend page

