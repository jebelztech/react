This extension adheres to Magenest.

For detailed user guide of this extension, please visit: https://confluence.izysync.com/display/DOC/2.+Image+Gallery+User+Guide

All updates of this module are included in CHANGELOG.md file.

Installation

Via Composer: run the following commands from root Magento 2 directory:
* composer require magenest/module-image-gallery
* php bin/magento setup:upgrade
* php bin/magento setup:di:compile
* php bin/magento setup:static-content:deploy
