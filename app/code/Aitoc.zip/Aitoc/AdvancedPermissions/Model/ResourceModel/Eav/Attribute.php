<?php
/**
 * @author Aitoc Team
 * @copyright Copyright (c) 2022 Aitoc (https://www.aitoc.com)
 * @package Aitoc_AdvancedPermissions
 */


namespace Aitoc\AdvancedPermissions\Model\ResourceModel\Eav;

use Magento\Framework\View\Element\Block\ArgumentInterface;

class Attribute extends \Magento\Catalog\Model\ResourceModel\Eav\Attribute implements ArgumentInterface
{

}